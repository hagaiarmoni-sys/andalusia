"""
POI Slideshow Video Generator
=============================

Creates a ~1 minute video slideshow from your itinerary POI photos.
Each POI shows for 3-4 seconds with a title overlay (City • POI Name).

Requirements:
    pip install pillow opencv-python numpy --break-system-packages
    
    For better video encoding (optional):
    - Install ffmpeg on your system

Usage:
    from poi_video_generator import generate_poi_slideshow
    
    # From itinerary result
    generate_poi_slideshow(result, output_file="my_trip.mp4")
    
    # Or from list of POIs
    pois = [
        {"name": "Alhambra", "city": "Granada", "place_id": "ChIJ..."},
        {"name": "Mezquita", "city": "Córdoba", "place_id": "ChIJ..."},
    ]
    generate_poi_slideshow_from_pois(pois, output_file="trip.mp4")

Author: Andalusia Travel App
"""

import os
import json
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

# ============================================================================
# CONFIGURATION
# ============================================================================

@dataclass 
class SlideshowConfig:
    """Configuration for slideshow video"""
    duration_per_slide: float = 3.5      # Seconds per POI
    fps: int = 24                         # Frames per second
    width: int = 1280                     # Video width
    height: int = 720                     # Video height
    transition_frames: int = 12           # Frames for fade transition
    
    # Text overlay settings
    font_size: int = 32
    title_font_size: int = 48
    text_color: Tuple[int, int, int] = (255, 255, 255)  # White
    shadow_color: Tuple[int, int, int] = (0, 0, 0)      # Black shadow
    overlay_opacity: float = 0.6          # Background overlay opacity
    
    # Paths
    photos_dir: str = "data/photos"       # Where POI photos are stored


# ============================================================================
# PATH CONFIGURATION
# ============================================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
PHOTOS_DIR = os.path.join(DATA_DIR, 'photos')


# ============================================================================
# PHOTO LOADING
# ============================================================================

def find_photo_path(poi: Dict, photos_dir: str = None) -> Optional[str]:
    """
    Find the photo file for a POI.
    
    Args:
        poi: POI dictionary with place_id or local_photo_path
        photos_dir: Directory containing photos
    
    Returns:
        Path to photo file, or None if not found
    """
    if photos_dir is None:
        photos_dir = PHOTOS_DIR
    
    # Option 1: Use local_photo_path directly
    local_path = poi.get('local_photo_path', '')
    if local_path:
        # Handle Windows-style paths
        local_path = local_path.replace('\\', os.sep).replace('/', os.sep)
        
        # Try as-is first
        if os.path.exists(local_path):
            return local_path
        
        # Try relative to photos_dir
        filename = os.path.basename(local_path)
        full_path = os.path.join(photos_dir, filename)
        if os.path.exists(full_path):
            return full_path
    
    # Option 2: Use place_id to construct filename
    place_id = poi.get('place_id', '')
    if place_id:
        photo_path = os.path.join(photos_dir, f"{place_id}.jpg")
        if os.path.exists(photo_path):
            return photo_path
        
        # Try PNG
        photo_path = os.path.join(photos_dir, f"{place_id}.png")
        if os.path.exists(photo_path):
            return photo_path
    
    # Option 3: Try constructing from name (fallback)
    name = poi.get('name', '')
    if name:
        # Normalize name for filename
        safe_name = name.lower().replace(' ', '_').replace("'", "")
        for ext in ['.jpg', '.jpeg', '.png']:
            photo_path = os.path.join(photos_dir, f"{safe_name}{ext}")
            if os.path.exists(photo_path):
                return photo_path
    
    return None


def load_and_resize_image(image_path: str, target_width: int, target_height: int):
    """
    Load an image and resize it to fit the target dimensions.
    Uses center crop to fill the frame without distortion.
    
    Args:
        image_path: Path to image file
        target_width: Target width in pixels
        target_height: Target height in pixels
    
    Returns:
        PIL Image object, or None if failed
    """
    try:
        from PIL import Image
        
        img = Image.open(image_path)
        
        # Convert to RGB if necessary
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Calculate aspect ratios
        img_aspect = img.width / img.height
        target_aspect = target_width / target_height
        
        # Resize to cover (then crop)
        if img_aspect > target_aspect:
            # Image is wider - fit height, crop width
            new_height = target_height
            new_width = int(target_height * img_aspect)
        else:
            # Image is taller - fit width, crop height
            new_width = target_width
            new_height = int(target_width / img_aspect)
        
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        # Center crop
        left = (new_width - target_width) // 2
        top = (new_height - target_height) // 2
        right = left + target_width
        bottom = top + target_height
        
        img = img.crop((left, top, right, bottom))
        
        return img
        
    except Exception as e:
        print(f"⚠️ Error loading image {image_path}: {e}")
        return None


def create_placeholder_image(width: int, height: int, text: str = "No Photo"):
    """Create a placeholder image when no photo is available"""
    from PIL import Image, ImageDraw, ImageFont
    
    # Create gradient background
    img = Image.new('RGB', (width, height), color=(40, 44, 52))
    draw = ImageDraw.Draw(img)
    
    # Add gradient effect
    for y in range(height):
        # Dark blue to purple gradient
        r = int(40 + (y / height) * 30)
        g = int(44 + (y / height) * 20)
        b = int(52 + (y / height) * 40)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    
    # Add text
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 48)
    except:
        font = ImageFont.load_default()
    
    # Center text
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (width - text_width) // 2
    y = (height - text_height) // 2
    
    draw.text((x, y), text, fill=(150, 150, 150), font=font)
    
    return img


# ============================================================================
# TEXT OVERLAY
# ============================================================================

def add_text_overlay(img, city: str, poi_name: str, config: SlideshowConfig = None):
    """
    Add text overlay to image with city and POI name.
    
    Args:
        img: PIL Image object
        city: City name
        poi_name: POI name
        config: SlideshowConfig instance
    
    Returns:
        PIL Image with overlay
    """
    from PIL import Image, ImageDraw, ImageFont
    
    if config is None:
        config = SlideshowConfig()
    
    img = img.copy()
    draw = ImageDraw.Draw(img, 'RGBA')
    
    width, height = img.size
    
    # Load fonts
    try:
        title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", config.title_font_size)
        subtitle_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", config.font_size)
    except:
        title_font = ImageFont.load_default()
        subtitle_font = ImageFont.load_default()
    
    # Text content
    title_text = poi_name
    subtitle_text = f"📍 {city}"
    
    # Calculate text dimensions
    title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
    subtitle_bbox = draw.textbbox((0, 0), subtitle_text, font=subtitle_font)
    
    title_width = title_bbox[2] - title_bbox[0]
    title_height = title_bbox[3] - title_bbox[1]
    subtitle_width = subtitle_bbox[2] - subtitle_bbox[0]
    subtitle_height = subtitle_bbox[3] - subtitle_bbox[1]
    
    # Padding
    padding = 20
    box_padding = 15
    
    # Calculate box dimensions (bottom left)
    box_width = max(title_width, subtitle_width) + box_padding * 2
    box_height = title_height + subtitle_height + box_padding * 3
    
    box_x = padding
    box_y = height - box_height - padding
    
    # Draw semi-transparent background box
    overlay_color = (0, 0, 0, int(255 * config.overlay_opacity))
    draw.rounded_rectangle(
        [(box_x, box_y), (box_x + box_width, box_y + box_height)],
        radius=10,
        fill=overlay_color
    )
    
    # Draw title (POI name)
    title_x = box_x + box_padding
    title_y = box_y + box_padding
    
    # Shadow
    draw.text((title_x + 2, title_y + 2), title_text, font=title_font, fill=(0, 0, 0, 180))
    # Main text
    draw.text((title_x, title_y), title_text, font=title_font, fill=config.text_color)
    
    # Draw subtitle (City)
    subtitle_x = box_x + box_padding
    subtitle_y = title_y + title_height + box_padding
    
    # Shadow
    draw.text((subtitle_x + 1, subtitle_y + 1), subtitle_text, font=subtitle_font, fill=(0, 0, 0, 150))
    # Main text  
    draw.text((subtitle_x, subtitle_y), subtitle_text, font=subtitle_font, fill=(200, 200, 200))
    
    return img


# ============================================================================
# VIDEO GENERATION
# ============================================================================

def generate_poi_slideshow_from_pois(
    pois: List[Dict],
    output_file: str = "trip_slideshow.mp4",
    config: SlideshowConfig = None,
    photos_dir: str = None
) -> Optional[str]:
    """
    Generate a slideshow video from a list of POIs.
    
    Args:
        pois: List of POI dictionaries with name, city, place_id
        output_file: Output video file path
        config: SlideshowConfig instance
        photos_dir: Directory containing photos
    
    Returns:
        Path to generated video, or None if failed
    """
    if config is None:
        config = SlideshowConfig()
    
    if photos_dir is None:
        photos_dir = PHOTOS_DIR
    
    try:
        from PIL import Image
        import cv2
        import numpy as np
    except ImportError as e:
        print(f"❌ Missing dependencies: {e}")
        print("   Install with: pip install pillow opencv-python numpy --break-system-packages")
        return None
    
    if not pois:
        print("❌ No POIs provided")
        return None
    
    print(f"🎬 Generating slideshow video for {len(pois)} POIs...")
    print(f"   Duration per slide: {config.duration_per_slide}s")
    print(f"   Resolution: {config.width}x{config.height}")
    print(f"   FPS: {config.fps}")
    
    # Calculate frames per slide
    frames_per_slide = int(config.duration_per_slide * config.fps)
    
    # Setup video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_file, fourcc, config.fps, (config.width, config.height))
    
    if not out.isOpened():
        print("❌ Failed to create video writer")
        return None
    
    total_frames = 0
    pois_with_photos = 0
    
    for idx, poi in enumerate(pois):
        poi_name = poi.get('name', 'Unknown')
        city = poi.get('city', 'Andalusia')
        
        print(f"   [{idx + 1}/{len(pois)}] {city} - {poi_name}")
        
        # Find and load photo
        photo_path = find_photo_path(poi, photos_dir)
        
        if photo_path:
            img = load_and_resize_image(photo_path, config.width, config.height)
            if img:
                pois_with_photos += 1
            else:
                img = create_placeholder_image(config.width, config.height, poi_name[:30])
        else:
            print(f"      ⚠️ No photo found")
            img = create_placeholder_image(config.width, config.height, poi_name[:30])
        
        # Add text overlay
        img_with_text = add_text_overlay(img, city, poi_name, config)
        
        # Convert PIL to OpenCV format
        frame = cv2.cvtColor(np.array(img_with_text), cv2.COLOR_RGB2BGR)
        
        # Write frames for this slide
        for _ in range(frames_per_slide):
            out.write(frame)
            total_frames += 1
        
        # Add simple fade transition (optional)
        if idx < len(pois) - 1 and config.transition_frames > 0:
            # Get next image for transition
            next_poi = pois[idx + 1]
            next_photo_path = find_photo_path(next_poi, photos_dir)
            
            if next_photo_path:
                next_img = load_and_resize_image(next_photo_path, config.width, config.height)
                if not next_img:
                    next_img = create_placeholder_image(config.width, config.height)
            else:
                next_img = create_placeholder_image(config.width, config.height)
            
            next_img_with_text = add_text_overlay(
                next_img, 
                next_poi.get('city', 'Andalusia'),
                next_poi.get('name', 'Unknown'),
                config
            )
            next_frame = cv2.cvtColor(np.array(next_img_with_text), cv2.COLOR_RGB2BGR)
            
            # Create fade frames
            for t in range(config.transition_frames):
                alpha = t / config.transition_frames
                blended = cv2.addWeighted(frame, 1 - alpha, next_frame, alpha, 0)
                out.write(blended)
                total_frames += 1
    
    out.release()
    
    duration = total_frames / config.fps
    print(f"\n✅ Video saved: {output_file}")
    print(f"   📊 Duration: {duration:.1f} seconds")
    print(f"   🖼️ POIs with photos: {pois_with_photos}/{len(pois)}")
    print(f"   🎞️ Total frames: {total_frames}")
    
    return output_file


def generate_poi_slideshow(
    result: Dict,
    output_file: str = "trip_slideshow.mp4",
    config: SlideshowConfig = None,
    photos_dir: str = None
) -> Optional[str]:
    """
    Generate a slideshow video from an itinerary result.
    
    Args:
        result: Itinerary result dictionary from the trip planner
        output_file: Output video file path
        config: SlideshowConfig instance
        photos_dir: Directory containing photos
    
    Returns:
        Path to generated video, or None if failed
    """
    # Extract POIs from itinerary
    pois = []
    itinerary = result.get('itinerary', [])
    
    for day in itinerary:
        cities_list = day.get('cities', [])
        for city_stop in cities_list:
            city_name = city_stop.get('city', '')
            attractions = city_stop.get('attractions', [])
            
            for attr in attractions:
                poi = {
                    'name': attr.get('name', 'Unknown'),
                    'city': city_name or attr.get('city', 'Andalusia'),
                    'place_id': attr.get('place_id', ''),
                    'local_photo_path': attr.get('local_photo_path', ''),
                    'photo_references': attr.get('photo_references', [])
                }
                pois.append(poi)
    
    if not pois:
        print("❌ No POIs found in itinerary")
        return None
    
    print(f"📍 Found {len(pois)} POIs in itinerary")
    
    return generate_poi_slideshow_from_pois(pois, output_file, config, photos_dir)


# ============================================================================
# STREAMLIT INTEGRATION
# ============================================================================

def add_slideshow_button_to_streamlit(result: Dict, st_module, photos_dir: str = None):
    """
    Add slideshow generation button to Streamlit app.
    
    Usage in trip_planner_page.py:
        from poi_video_generator import add_slideshow_button_to_streamlit
        add_slideshow_button_to_streamlit(result, st)
    
    Args:
        result: Itinerary result dict
        st_module: Streamlit module
        photos_dir: Directory containing photos
    """
    st = st_module
    
    if st.button("🎬 Generate Trip Slideshow", use_container_width=True, key="gen_slideshow_btn"):
        with st.spinner("Creating your trip video... This may take a minute."):
            try:
                output_file = f"trip_slideshow_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
                
                config = SlideshowConfig(
                    duration_per_slide=3.5,
                    fps=24,
                    width=1280,
                    height=720
                )
                
                video_path = generate_poi_slideshow(result, output_file, config, photos_dir)
                
                if video_path and os.path.exists(video_path):
                    # Read video file
                    with open(video_path, 'rb') as f:
                        video_data = f.read()
                    
                    # Offer download
                    st.download_button(
                        label="📥 Download Trip Video (MP4)",
                        data=video_data,
                        file_name="andalusia_trip_slideshow.mp4",
                        mime="video/mp4",
                        use_container_width=True
                    )
                    
                    st.success("✅ Video generated successfully!")
                    
                    # Cleanup
                    try:
                        os.remove(video_path)
                    except:
                        pass
                else:
                    st.error("❌ Failed to generate video. Check that photos exist.")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
                import traceback
                st.code(traceback.format_exc())


# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

if __name__ == "__main__":
    import sys
    
    print("=" * 60)
    print("🎬 POI SLIDESHOW VIDEO GENERATOR")
    print("=" * 60)
    print()
    
    # Example POIs for testing
    sample_pois = [
        {"name": "Alhambra", "city": "Granada", "place_id": "ChIJfcIyLeb5cQ0RjWyTrk1cCj8"},
        {"name": "Mezquita-Catedral", "city": "Córdoba", "place_id": "ChIJn_kDnvxyQA0R1V9VlPhCnEc"},
        {"name": "Real Alcázar", "city": "Seville", "place_id": "ChIJkdOGu2_7cg0RVkKiLchRBIM"},
        {"name": "Plaza de España", "city": "Seville", "place_id": "ChIJLVPwFHb7cg0R3bM3WJUjXyQ"},
        {"name": "Puente Nuevo", "city": "Ronda", "place_id": "ChIJw0rTvFSucg0RNvlzPuyVAv8"},
    ]
    
    if len(sys.argv) > 1:
        # Load itinerary from JSON file
        json_path = sys.argv[1]
        output = sys.argv[2] if len(sys.argv) > 2 else "trip_slideshow.mp4"
        photos = sys.argv[3] if len(sys.argv) > 3 else "data/photos"
        
        print(f"📂 Loading itinerary from: {json_path}")
        
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                result = json.load(f)
            
            generate_poi_slideshow(result, output, photos_dir=photos)
            
        except Exception as e:
            print(f"❌ Error: {e}")
    else:
        print("📍 Using sample POIs for demo...")
        print()
        
        # Check if photos directory exists
        if os.path.exists(PHOTOS_DIR):
            print(f"✅ Photos directory found: {PHOTOS_DIR}")
            photos = os.listdir(PHOTOS_DIR)[:5]
            print(f"   Sample photos: {photos}")
        else:
            print(f"⚠️ Photos directory not found: {PHOTOS_DIR}")
            print("   Will use placeholder images")
        
        print()
        print("=" * 60)
        print("Usage:")
        print("  python poi_video_generator.py <itinerary.json> [output.mp4] [photos_dir]")
        print()
        print("Examples:")
        print("  python poi_video_generator.py trip.json")
        print("  python poi_video_generator.py trip.json my_video.mp4 data/photos")
        print()
        print("To integrate with Streamlit:")
        print("  from poi_video_generator import add_slideshow_button_to_streamlit")
        print("  add_slideshow_button_to_streamlit(result, st)")
        print("=" * 60)
